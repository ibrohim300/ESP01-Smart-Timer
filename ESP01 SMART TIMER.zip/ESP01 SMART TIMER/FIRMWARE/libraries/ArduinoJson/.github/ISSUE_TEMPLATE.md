<!--
Thanks for using ArduinoJson :-)

Before opening an issue, please make sure you've read these:
https://bblanchon.github.io/ArduinoJson/faq/
https://bblanchon.github.io/ArduinoJson/doc/pitfalls/

Next, make sure you provide all the relevant information: platform, code snippet, and error messages.

Please be concise!
-->
